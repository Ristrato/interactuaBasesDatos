'use strict';

$(function() {
    $('#logout').on('click', function() {
        window.location.href = '/';
    });
});
